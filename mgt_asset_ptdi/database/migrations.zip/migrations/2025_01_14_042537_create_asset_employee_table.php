<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('asset_employee', function (Blueprint $table) {
            $table->id();
            $table->string('nomor_asset')->unique();
            $table->string('nik');
            $table->foreign('nik')->references('nik')->on('employee')->onDelete('cascade');
            $table->string('lokasi');
            $table->string('nomor_it');
            $table->foreign('nomor_it')->references('nomor_it')->on('device')->onDelete('cascade');
            $table->integer('status_pengalihan')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('asset_employee');
    }
};
