<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('device', function (Blueprint $table) {
            $table->id();
            $table->string('nomor_it')->unique();
            $table->string('kode_kategori');
            $table->foreign('kode_kategori')->references('kode_kategori')->on('kategori')->onDelete('cascade');
            $table->string('processor');
            $table->foreign('processor')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->string('storage_type');
            $table->foreign('storage_type')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->integer('storage_capacity');
            $table->string('memory_type');
            $table->foreign('memory_type')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->integer('memory_capacity');
            $table->string('vga_type');
            $table->foreign('vga_type')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->string('operation_system');
            $table->foreign('operation_system')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->string('os_license');
            $table->foreign('os_license')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->string('office');
            $table->foreign('office')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->string('office_license');
            $table->foreign('office_license')->references('kode_type')->on('type_kategori')->onDelete('cascade');
            $table->string('aplikasi_lainnya');
            $table->string('keterangan_tambahan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('device');
    }
};
