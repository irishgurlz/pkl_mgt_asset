@extends('employee.master')

@section('content')
<div class="container section-title" data-aos="fade-up">
    <h2>Edit Jabatan</h2>
</div><!-- End Section Title -->
  <div class="container">
    <div class="row g-5 d-flex justify-content-center">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive d-flex justify-content-center">
                    <form action="/jabatan/{{$jabatan->id}}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
            
                        <div class="mt-2 d-flex justify-content-between">
                            <div class="me-3">
                                Jabatan
                            </div>
                            <input type="text" class="input-form" name="nama" value="{{ old('nama', $jabatan->nama) }}"> 
                        </div>
                        @error('nama')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror

                        <div class="d-flex justify-content-end mt-3">
                            <a href="/jabatan" class="btn btn-cancel me-2" style="width:25%;">Cancel</a>
                            <button type="submit" class="btn btn-add" style="width:25%;">Add</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
  </div>
@endsection
