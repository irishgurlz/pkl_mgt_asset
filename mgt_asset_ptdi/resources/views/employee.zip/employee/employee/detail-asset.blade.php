@extends('employee.master')

@section('content')

<div class="container section-title" data-aos="fade-up">
    <h2>Daftar Asset {{$employee->nama}}</h2>
    {{-- <small>NIK : {{$employee->nik}}</small> --}}
</div>

  <div class="container">
    <div class="row g-5">
        <div class="card shadow mb-4">
            <input type="hidden" name="id" id="id" value="{{ $employee->id}}">
            {{-- @dd($employee->id) --}}
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="data-table" width="100%" cellspacing="4" style="overflow-x:auto">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nomor Asset</th>
                                <th>Nomor IT</th>
                                <th>Kategori</th>
                                <th>Processor</th>
                                <th>Storage Type</th>
                                <th>Storage Capacity</th>
                                <th>Memory Type</th>
                                <th>Memory Capacity</th>
                                <th>Serial Number</th>
                                <th>VGA Type</th>
                                <th>operation System</th>
                                <th>Office</th>
                                <th>OS License</th>
                                <th>Office License</th>
                                <th>Aplikasi Lainnya</th>
                                <th>Keterangan Tambahan</th>
                            </tr>
                        </thead>
                        <tbody>
                        {{-- @dd($employee->nik) --}}
                        @forelse ($asset as $key => $item)    
                                <tr>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nomor_asset}}</td>
                                    <td>{{$item->nomor_it}}</td>
                                    <td>{{$item->asset->kategori->nama}}</td>
                                    <td>{{$item->asset->processorType->nama}}</td>
                                    <td>{{$item->asset->storageType->nama}}</td>
                                    <td>{{$item->asset->storage_capacity}}</td>
                                    <td>{{$item->asset->memoryType->nama}}</td>
                                    <td>{{$item->asset->memory_capacity}}</td>
                                    <td>{{$item->asset->serial_number ?? '-'}}</td>
                                    <td>{{$item->asset->vgaType->nama}}</td>
                                    <td>{{$item->asset->operationSystem->nama}}</td>
                                    <td>{{$item->asset->officeType->nama}}</td>
                                    <td>{{$item->asset->osLicense->nama}}</td>
                                    <td>{{$item->asset->officeLicense->nama}}</td>
                                    <td>{{$item->asset->aplikasi_lainnya ?? '-'}}</td>
                                    <td>{{$item->asset->keterangan_tambahan ?? '-'}}</td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center">Tidak ada data aset</td>
                                </tr>
                                @endforelse
                            </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
  </div>
@endsection
