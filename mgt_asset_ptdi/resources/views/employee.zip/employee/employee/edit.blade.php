@extends('employee.master')

@section('content')
<div class="container section-title" data-aos="fade-up">
    <h2>Edit Employee</h2>
</div><!-- End Section Title -->
  <div class="container">
    <div class="row g-5 d-flex justify-content-center">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive d-flex justify-content-center">
                    <form action="/employee/{{$employee->id}}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="mt-2 d-flex justify-content-between">
                            <div class="me-3">
                                Nama Employee
                            </div>
                            <input type="text" class="input-form" name="nama" value="{{ old('nama', $employee->nama) }}" > 
                        </div>
                        @error('nama')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror
            
                        <div class="mt-2 d-flex justify-content-between">
                            <div class="me-3">
                                NIK Employee
                            </div>
                            <input type="text" class="input-form" name="nik" value="{{ old('nama', $employee->nik) }}"> 
                        </div>
                        @error('nik')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror


                        <div class="mt-2 d-flex justify-content-between">
                            <div class="me-3">
                                Organisasi
                            </div>
                            <select name="kode_org" class="input-form">
                                <option value="" disabled selected >--Pilih Organisasi--</option>
                                @forelse ($org as $item)
                                    <option value="{{$item->kode_org}}">{{$item->nama}}</option>
                                @empty
                                    <option value="">Tidak Ada Organisasi</option>
                                @endforelse
                            </select>
                        </div>
                        @error('kode_org')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror

                        <div class="mt-2 d-flex justify-content-between">
                            <div class="me-3">
                                Jabatan
                            </div>
                            <select name="kode_jabatan" class="input-form">
                                <option value="" disabled selected>--Pilih Jabatan--</option>
                                @forelse ($jabatan as $item)
                                    <option value="{{$item->id}}">{{$item->nama}}</option>
                                @empty
                                    <option value="">Tidak Ada Jabatan</option>
                                @endforelse
                            </select>
                        </div>
                        @error('kode_jabatan')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror

                        <div class="d-flex justify-content-end mt-3">
                            <a href="/employee" class="btn btn-cancel me-2" style="width:25%;">Cancel</a>
                            <button type="submit" class="btn btn-add" style="width:25%;">Add</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
  </div>
@endsection
