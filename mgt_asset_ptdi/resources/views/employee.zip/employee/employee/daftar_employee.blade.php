    @extends('employee.master')


    @section('content')

        <!-- TITLE -->
    <div class="container" data-aos="fade-up">
            <div class ="section-title" data-aos="fade-up" >
                <h2>Daftar Employee</h2>
            </div>

            <div class="container-fluid">
                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <div class="card shadow mb-4">
                    <div class="card-header py-3">

                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="m-0 font-weight-bold">
                                    <a class="btn btn-primary" href="/employee/create">+ Tambah Employee</a>
                                </h6>
                            </div>
                            
                            <form id="searchForm" method="GET">
                                <div class="mb-3 d-flex justify-content-between"">
                                    <div class="input-group me-2">
                                        <input type="text" class="form-control" id="search" name="search" placeholder="Search Employee" value="{{ request('search') }}">
                                    </div>
                                    <button class="btn btn-primary" type="submit">Search</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- TABEL -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" id="tableData" width="100%" cellspacing="0" style="table-layout: auto;">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Employee NIK</th>
                                        <th>Employee Name</th>
                                        <th>Employee Org</th>
                                        <th>Employee Level</th>
                                        <th>Detail Asset</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                @include('employee.component.table-employee')
                            </table>
                            @include('paginate', ['paginator' => $employee])
                        </div>
                    </div>
            </div>
            
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('search');

            searchInput.addEventListener('keyup', function(event) {
                let searchQuery = searchInput.value;

                fetch("{{ route('employee.index') }}?search=" + searchQuery, {
                    method: 'GET',
                    headers: {
                        'Accept': 'text/html',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.text())
                .then(data => {
                    // Update the table content dynamically
                    document.querySelector('tbody').innerHTML = data;
                });
            });
        });
    </script>
    @endsection