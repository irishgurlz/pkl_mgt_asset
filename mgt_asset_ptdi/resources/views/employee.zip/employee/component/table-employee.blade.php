<tbody>
    @forelse ($employee as $key => $item)    
        <tr>
            <td>{{ $key + 1 }}</td>
            <td>{{$item->nik}}</td>
            <td>{{$item->nama}}</td>
            <td>{{$item->org->nama}}</td>
            <td>{{$item->jabatan->nama}}</td>
            <td>
                <a class="btn btn-info" href="/employee/{{$item->id}}/asset">
                    {{-- <i class="bi bi-eye-fill"></i> --}}Detail
                </a>
            </td>
            <td class="d-flex justify-content-start">
                <div class="me-2">
                    <a class="btn btn-warning" href="/employee/{{$item->id}}/edit">
                        {{-- <i class="bi bi-pencil-fill"></i> --}}Edit
                    </a>
                    
                </div>

                <form action="/employee/{{ $item->id }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this employee?');" style="padding: 0; margin: 0;">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger" type="submit" style="">
                        {{-- <i class="bi bi-trash3-fill"></i> --}}Delete
                    </button>
                </form>
            </td>
        </tr>
        <form action="/employee/{{$item->id}}/asset">
            <input type="hidden" name="id" id="employee" value="{{ $item->id }}">
            </div>
        </form>
    @empty
        <tr>
            <td colspan="7" class="text-center">Tidak ada data employee</td>
        </tr>
    @endforelse
</tbody>
