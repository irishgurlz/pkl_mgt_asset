<!-- Modal -->
<div class="modal fade" id="modal-detail-asset" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" style="margin-left:35%; width:100%">
        <div class="modal-content" style="background-color: #ffffff; border-radius: 15px; max-width: 100%;">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detail Device</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body">
                <div class="container">
                    <table>
                        <thead>
                            <tr>
                                <th>Nomor Asset</th>
                                <th>Nomor IT</th>
                                <th>Kategori</th>
                                <th>Processor</th>
                                <th>Storage Capacity</th>
                                <th>Memory Capacity</th>
                                <th>Nomor Asset</th>
                                <th>Serial Number</th>
                                <th>Serial Number</th>
                                <th>Storage Type</th>
                                <th>Memory Type</th>
                                <th>VGA Type</th>
                                <th>operation System</th>
                                <th>Office</th>
                                <th>OS License</th>
                                <th>Aplikasi Lainnya</th>
                                <th>Keterangan Tambahan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                    {{-- <div class="row mb-3">
                        <div class="col-5 fw-bold">Nomor IT:</div>
                        <div class="col-7" id="modal-nomor-it"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Kategori:</div>
                        <div class="col-7" id="modal-kategori"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Processor:</div>
                        <div class="col-7" id="modal-processor"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Tipe Storage:</div>
                        <div class="col-7" id="modal-storage-type"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Storage Capacity:</div>
                        <div class="col-7" id="modal-storage-capacity"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Tipe Memory:</div>
                        <div class="col-7" id="modal-memory-type"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Memory Capacity:</div>
                        <div class="col-7" id="modal-memory-capacity"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Tipe VGA:</div>
                        <div class="col-7" id="modal-vga-type"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Operation System:</div>
                        <div class="col-7" id="modal-os"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">OS License:</div>
                        <div class="col-7" id="modal-os-license"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Office:</div>
                        <div class="col-7" id="modal-office"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Office License:</div>
                        <div class="col-7" id="modal-office-license"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Aplikasi Lainnya:</div>
                        <div class="col-7" id="modal-aplikasi"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-5 fw-bold">Keterangan Tambahan:</div>
                        <div class="col-7" id="modal-keterangan"></div>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>
</div>
{{-- 
<script>
    var myModal = document.getElementById('modal-detail-device');
    myModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // The button that triggered the modal
        document.getElementById('modal-nomor-it').textContent = button.getAttribute('data-nomor-it');
        document.getElementById('modal-kategori').textContent = button.getAttribute('data-kategori');
        document.getElementById('modal-processor').textContent = button.getAttribute('data-processor');
        document.getElementById('modal-storage-type').textContent = button.getAttribute('data-storage-type');
        document.getElementById('modal-storage-capacity').textContent = button.getAttribute('data-storage-capacity') + " GB";
        document.getElementById('modal-memory-type').textContent = button.getAttribute('data-memory-type');
        document.getElementById('modal-memory-capacity').textContent = button.getAttribute('data-memory-capacity') + " GB";
        document.getElementById('modal-vga-type').textContent = button.getAttribute('data-vga-type');
        document.getElementById('modal-os').textContent = button.getAttribute('data-os');
        document.getElementById('modal-os-license').textContent = button.getAttribute('data-os-license');
        document.getElementById('modal-office').textContent = button.getAttribute('data-office');
        document.getElementById('modal-office-license').textContent = button.getAttribute('data-office-license');
        document.getElementById('modal-aplikasi').textContent = button.getAttribute('data-aplikasi');
        document.getElementById('modal-keterangan').textContent = button.getAttribute('data-keterangan');
    });
</script> --}}


