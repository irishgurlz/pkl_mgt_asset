@extends('employee.master')

@section('content')
<!-- TITLE -->
<div class="container section-title" data-aos="fade-up">
    <h2>Pengalihan Asset</h2>
</div><!-- End Section Title -->
  <div class="container">
    <div class="row g-5 d-flex justify-content-center">
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive" style="overflow:hidden">
                    <form action="/distribusi/{{ $distribution->nomor_penyerahan }}/asset/{{ $distribution->asset->id }}/updatePengalihan" id="form-add-asset" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <div class="form-group mb-3">
                                <label for="nomor_penyerahan" class="form-label">Nomor Penyarahan</label>
                                <input type="text" name="nomor_penyerahan" id="nomor_penyerahan" placeholder="Masukkan Nomor Penyerahan" class="form-control" value="{{ old('nomor_penyerahan', $distribution->nomor_penyerahan) }}" style="background-color: #f2f2f2;" required readonly>
                                @error('nomor_penyerahan')
                                    <div class="alert alert-danger">{{$message}}</div>
                                @enderror
                            </div>
                  
                        </div>

                        <div class="row">
                            <div class=" col col-6">
                                <div class="'row">

                                    <!-- Card Pengguna -->
                                    <div class="card shadow mb-3">
                                        <div class="card-header py-3 text-center">
                                            <h6 class="m-0 font-weight-bold text-gray">Pengguna</h6>
                                        </div>
                                        <div class="card-body">
        
                                            <!-- NIK Pemilik Asset -->
                                            <div class="form-group mb-3">
                                                <label for="nik" class="form-label">NIK</label>
                                                <input type="text" name="nik" id="nik" placeholder="Masukkan NIK" class="form-control" onkeyup="fetchUserData()" required value="{{ old('nik', $distribution->nik ?? '') }}">
                                                <div id="nik-status" style="color: blue; font-size: 14px;"></div>

                                                @error('nik')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
        
                                            <!-- Nama Pemilik Asset -->
                                            <div class="form-group mb-3">
                                                <label for="nama" class="form-label">Nama</label>
                                                <input type="text" name="nama" id="nama" placeholder="Nama" class="form-control" style="background-color: #f2f2f2;" required readonly value="{{ old('nama', $distribution->employee->nama ?? '') }}">
                                                @error('nama')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
                
                                            <!-- Organisasi -->
                                            <div class="form-group mb-3">
                                                <label for="kode_org" class="form-label">Organisasi</label>
                                                <input type="text" name="kode_org" id="kode_org" placeholder="Organisasi" class="form-control" style="background-color: #f2f2f2;" required readonly value="{{ old('kode_org', $distribution->employee->org->nama ?? '') }}">
                                                @error('kode_org')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
                
                                            <!-- Lokasi -->
                                            <div class="form-group mb-3">
                                                <label for="lokasi" class="form-label">Lokasi</label>
                                                <input type="text" name="lokasi" id="lokasi" placeholder="Masukkan Lokasi" class="form-control" required value="{{ old('lokasi', $distribution->lokasi ?? '') }}">
                                                @error('lokasi')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                   
                                <div class="card shadow mb-3">
                                    <div class="card-header py-3 text-center">
                                        <h6 class="m-0 font-weight-bold text-gray">Distribusi</h6>
                                    </div>
                                    <div class="card-body">
                                        <label for="file" class="form-label">Dokumen</label>
                                        <input type="file" name="file" class="form-control" style="background-color: #f2f2f2;" value="{{ old('file', $distribution->file ?? '') }}" readonly>
                                        @error('file')
                                            <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>


                                    <div class="card-body">
                                        <div class="form-group ">
                                            <label for="tanggal" class="form-label"  value="{{ old('tanggal', $distribution->tanggal  ?? '') }}">Tanggal</label>
                                            <input type="date" name="tanggal" id="tanggal" style="background-color: #f2f2f2;" placeholder="Masukkan Tanggal" class="form-control" value="{{ old('tanggal', $distribution->tanggal ?? '') }}" required readonly>
                                            @error('tanggal')
                                                <div class="alert alert-danger">{{$message}}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <label for="deskripsi" class="form-label">Deskripsi</label>
                                        <textarea class="col-lg-12" name="deskripsi" style="background-color: #f2f2f2;" placeholder="Deskripsi" style="height:150px;" readonly>{{ old('deskripsi', $distribution->deskripsi ?? '') }}</textarea>
                                        @error('deskripsi')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                                </div>
                                
                                <div class="card shadow mb-3">
                                    <div class="card-header py-3 text-center">
                                        <h6 class="m-0 font-weight-bold text-gray">Pengalihan</h6>
                                    </div>
                                    <div class="card-body">
                                        <label for="lokasi" class="form-label">Dokumen Pengalihan</label>
                                        <input type="file" name="file_pengalihan" class="form-control" accept=".pdf" required placeholder="Upload dokumen PDF">
                                        <small class="text-muted">Upload dokumen PDF.</small>
                                        @error('file_pengalihan')
                                            <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>    
                            </div>

                            <div class=" col col-6">
                                <div>
                                
                                <!-- Card Perangkat -->
                                <div class="card shadow mb-3">
                                    <div class="card-header py-3 text-center">
                                        <h6 class="m-0 font-weight-bold text-gray">Perangkat</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <!-- Nomor IT -->
                                            <div class="form-group mb-3">
                                                <label for="nomor_it" class="form-label">Nomor IT</label>
                                                <input type="text" name="nomor_it" id="nomor_it" placeholder="Masukkan Nomor IT" style="background-color: #f2f2f2;"  class="form-control" value="{{ old('nomor_it', $distribution->nomor_it) }}" required readonly>
                                                @error('nomor_it')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
                                            
                                            <!-- Kategori -->
                                            <div class="form-group mb-3">
                                                <label for="id_kategori" class="form-label">Kategori</label>
                                                <input type="text" id="id_kategori" name="id_kategori" class="form-control" style="background-color: #f2f2f2;"
                                                    value="{{ old('id_kategori', $distribution->asset->kategori->nama ?? '') }}" readonly>
                                                <input type="hidden" name="id_kategori" 
                                                    value="{{ old('id_kategori', $distribution->asset->id_kategori ?? '') }}">
                                                
                                                @error('id_kategori')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
                                            
                                            <!-- Tipe Kategori -->
                                            <div class="form-group mb-3">
                                                <label for="id_tipe" class="form-label">Tipe Kategori</label>
                                                <input type="text" id="id_tipe" name="id_tipe" class="form-control" style="background-color: #f2f2f2;"
                                                    value="{{ old('id_tipe', $distribution->asset->subKategori->nama ?? '') }}" readonly>
                                                <input type="hidden" name="id_tipe" value="{{ old('id_tipe', $distribution->asset->id_tipe ?? '') }}">

                                                @error('id_tipe')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
                                            {{-- @dd($distribution->asset->umur) --}}
                                            <div class="form-group mb-3">
                                                <label for="umur" class="form-label">Tanggal Masuk</label>
                                                <input type="date" name="umur" id="umur" placeholder="Masukkan Tanggal" class="form-control" value="{{ old('umur', $distribution->asset->umur ?? '') }}" style="background-color: #f2f2f2;" required readonly>
                                                <div class="d-flex justify-content-between">
                                                    <div class="align-items-center mt-3">
                                                        <label for="umur" class="form-label">Umur saat ini</label>
                                                    </div>
                                                    <div style="width:80%">
                                                        <input type="text" id="umur_tahun" placeholder="Umur dalam tahun" class="form-control mt-2" style="background-color: #f2f2f2;" readonly>
                                                    </div>
                                                </div>
                                                @error('umur')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>
                                            
                                            <script>
                                                document.addEventListener('DOMContentLoaded', function() {
                                                    const dateInput = document.getElementById('umur');
                                                    const umurTahunInput = document.getElementById('umur_tahun');
                                            
                                                    function calculateAge(dateOfBirth) {
                                                        const today = new Date();
                                                        const birthDate = new Date(dateOfBirth);
                                                        let age = today.getFullYear() - birthDate.getFullYear();
                                                        const monthDiff = today.getMonth() - birthDate.getMonth();
                                            
                                                        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                                                            age--;
                                                        }
                                                        return age;
                                                    }
                                            
                                                    dateInput.addEventListener('change', function() {
                                                        const umur = calculateAge(dateInput.value);
                                                        umurTahunInput.value = umur >= 0 ? `${umur} tahun` : 'Tanggal tidak valid';
                                                    });
                                            
                                                    if (dateInput.value) {
                                                        const umur = calculateAge(dateInput.value);
                                                        umurTahunInput.value = umur >= 0 ? `${umur} tahun` : 'Tanggal tidak valid';
                                                    }
                                                });
                                            </script>
                                        </div>
                                        
                                        <div class="row">
                                            <!-- Kolom Pertama -->
                                            <div class="col col-6">
                                                <!-- Processor -->
                                                <div class="form-group mb-3">
                                                    <label for="processor" class="form-label">Processor</label>
                                                    <input type="text" id="processor" name="processor" class="form-control" style="background-color: #f2f2f2;"
                                                        value="{{ old('processor', $distribution->asset->processorType->nama ?? '') }}" readonly>
                                                    <input type="hidden" name="processor" value="{{ old('processor', $distribution->asset->processor ?? '') }}">
    
                                                    @error('processor')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>
                                
                                                <!-- Storage Type -->
                                                <div class="form-group mb-3">
                                                    <label for="storage_type" class="form-label">Storage Type</label>
                                                    <input type="text" id="storage_type" name="storage_type" class="form-control" style="background-color: #f2f2f2;"
                                                        value="{{ old('storage_type', $distribution->asset->storageType->nama ?? '') }}" readonly>
                                                    <input type="hidden" name="storage_type" value="{{ old('storage_type', $distribution->asset->storage_type ?? '') }}">
    
                                                    @error('storage_type')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>
                                
                                                <!-- Memory Type -->
                                                <div class="form-group mb-3">
                                                    <label for="memory_type" class="form-label">Memory Type</label>
                                                    <input type="text" name="memory_type" class="form-control" style="background-color: #f2f2f2;"
                                                        value="{{ old('memory_type', $distribution->asset->memoryType->nama ?? '') }}" readonly>
                                                    <input type="hidden" name="memory_type" value="{{ old('memory_type', $distribution->asset->memory_type ?? '') }}">
                                                    @error('memory_type')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>

                                                <!-- VGA Type -->
                                                <div class="form-group mb-3">
                                                    <label for="vga_type" class="form-label">VGA Type</label>
                                                    <input type="text" name="vga_type" class="form-control" style="background-color: #f2f2f2;"
                                                        value="{{ old('vga_type', $distribution->asset->vgaType->nama ?? '') }}" readonly>
                                                    <input type="hidden" name="vga_type" value="{{ old('vga_type', $distribution->asset->vga_type ?? '') }}">
                                                    @error('vga_type')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                            
                                            <!-- Kolom Kedua -->
                                            <div class="col col-6">
                                                <div class="form-group mb-3">
                                                    <label for="serial_number" class="form-label">Serial Number</label>
                                                    <input type="text" name="serial_number" id="serial_number" placeholder="Masukkan Serial Number" class="form-control" style="background-color: #f2f2f2;"
                                                        value="{{ old('serial_number', $distribution->asset->serial_number) }}" required readonly>
                                                    <input type="hidden" name="serial_number" value="{{ old('serial_number', $distribution->asset->serial_number) }}">
                                                
                                                    @error('serial_number')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>
                                                
                                
                                                <!-- Storage Capacity -->
                                                <div class="form-group mb-3">
                                                    <label for="storage_capacity" class="form-label">Storage Capacity</label>
                                                    <input type="text" name="storage_capacity" id="storage_capacity" style="background-color: #f2f2f2;" placeholder="Storage Capacity GB" class="form-control" value="{{ old('storage_capacity', $distribution->asset->storage_capacity) }}" required readonly>
                                                    @error('storage_capacity')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>
                                
                                                <!-- Memory Capacity -->
                                                <div class="form-group mb-3">
                                                    <label for="memory_capacity" class="form-label">Memory Capacity</label>
                                                    <input type="text" name="memory_capacity" id="memory_capacity" style="background-color: #f2f2f2;" placeholder="Memory Capacity GB" class="form-control" value="{{ old('memory_capacity', $distribution->asset->memory_capacity) }}" required readonly>
                                                    @error('memory_capacity')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>
                                
                                                <!-- VGA Capacity -->
                                                <div class="form-group mb-3">
                                                    <label for="vga_capacity" class="form-label">VGA Capacity</label>
                                                    <input type="text" name="vga_capacity" id="vga_capacity" style="background-color: #f2f2f2;" placeholder="VGA Capacity GB" class="form-control" value="{{ old('vga_capacity', $distribution->asset->vga_capacity) }}" required readonly>
                                                    @error('vga_capacity')
                                                        <div class="alert alert-danger">{{$message}}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <label for="keterangan_tambahan" class="form-label">Keterangan Tambahan</label>
                                            <textarea class="col-lg-12" name="keterangan_tambahan" style="background-color: #f2f2f2;" placeholder="Keterangan Tambahan" style="height:150px;" readonly>{{ old('keterangan_tambahan', $distribution->asset->keterangan_tambahan ?? '') }}</textarea>
                                            @error('keterangan_tambahan')
                                                <div class="alert alert-danger">{{$message}}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                
                    
                                <!-- Card Aplikasi -->
                                <div class="card shadow mb-3">
                                    <div class="card-header py-3 text-center">
                                        <h6 class="m-0 font-weight-bold text-gray">Aplikasi</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <!-- Kolom Pertama -->
                                            <div class="row">
                                                <div class="col col-6">
                                                    <!-- Memory Type -->
                                                    <div class="form-group mb-3">
                                                        <label for="operation_system" class="form-label">Operation System</label>
                                                        <input type="text" name="operation_system" style="background-color: #f2f2f2;" class="form-control" 
                                                            value="{{ old('operation_system', $distribution->asset->operationSystem->nama ?? '') }}" readonly>
                                                        <input type="hidden" name="operation_system" 
                                                            value="{{ old('operation_system', $distribution->asset->operation_system ?? '') }}">
                                                        
                                                        @error('operation_system')
                                                            <div class="alert alert-danger">{{$message}}</div>
                                                        @enderror
                                                    </div>
                                                    
                                                    <!-- Office Type -->
                                                    <div class="form-group mb-3">
                                                        <label for="office" class="form-label">Office Type</label>
                                                        <input type="text" name="office" class="form-control" style="background-color: #f2f2f2;"
                                                            value="{{ old('office', $distribution->asset->officeType->nama ?? '') }}" readonly>
                                                        <input type="hidden" name="office" 
                                                            value="{{ old('office', $distribution->asset->officeType->id ?? '') }}">
                                                        
                                                        @error('office')
                                                            <div class="alert alert-danger">{{$message}}</div>
                                                        @enderror
                                                    </div>
                                                    
                                                </div>
                                                
                                                <!-- Kolom Kedua -->
                                                <div class="col col-6">
                                                    <div class="form-group mb-3">
                                                        <label for="os_license" class="form-label">Operation System License</label>
                                                        <input type="text" name="os_license" class="form-control" style="background-color: #f2f2f2;"
                                                            value="{{ old('os_license', $distribution->asset->osLicense->nama ?? '') }}" readonly>
                                                        <input type="hidden" name="os_license" 
                                                            value="{{ old('os_license', $distribution->asset->osLicense->id ?? '') }}">
                                                        
                                                        @error('os_license')
                                                            <div class="alert alert-danger">{{$message}}</div>
                                                        @enderror
                                                    </div>
                                                    
                                                    <!-- Office License -->
                                                    <div class="form-group mb-3">
                                                        <label for="office_license" class="form-label">Office License</label>
                                                        <input type="text" name="office_license" class="form-control" style="background-color: #f2f2f2;"
                                                            value="{{ old('office_license', $distribution->asset->officeLicense->nama ?? '') }}" readonly>
                                                        <input type="hidden" name="office_license" 
                                                            value="{{ old('office_license', $distribution->asset->officeLicense->id ?? '') }}">
                                                        
                                                        @error('office_license')
                                                            <div class="alert alert-danger">{{$message}}</div>
                                                        @enderror
                                                    </div>
                                                    
                                                </div>
                                            </div>  
                                            
                                            <!-- Aplikasi Lainnya -->
                                            <div class="form-group mb-3">
                                                <label for="aplikasi_lainnya" class="form-label">Aplikasi Lainnya</label>
                                                <input type="text" name="aplikasi_lainnya" id="apk_lain" style="background-color: #f2f2f2;" placeholder="Aplikasi Lainnya" class="form-control" value="{{ old('aplikasi_lainnya', $distribution->asset->aplikasi_lainnya ?? '') }}" required>
                                                @error('aplikasi_lainnya')
                                                    <div class="alert alert-danger">{{$message}}</div>
                                                @enderror
                                            </div>

                                            <input type="hidden" name="status_pengalihan" value="{{$distribution->status_pengalihan + 1}}">
                                            
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            </div>
                            </div>
                        </div>

                    <div class="d-flex justify-content-end mt-4">
                        <button type="button" class="btn btn-danger me-2" style="width: 120px;">Batal</button>
                        <button type="submit" class="btn btn-primary" style="width: 120px;">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    document.getElementById('id_kategori').addEventListener('change', function () {
        const kategoriId = this.value;
        const tipeDropdown = document.getElementById('id_tipe');

        tipeDropdown.innerHTML = '<option value="" disabled selected>-- Pilih Tipe Kategori --</option>';

        if (kategoriId) {
            fetch(`/get-tipe-by-kategori/${kategoriId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        data.forEach(item => {
                            const option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = item.nama;
                            tipeDropdown.appendChild(option);
                        });
                    } else {
                        const option = document.createElement('option');
                        option.value = '';
                        option.textContent = 'Tidak Ada Tipe Kategori';
                        tipeDropdown.appendChild(option);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    });

    function fetchUserData() {
        let nik = $('#nik').val(); 

        if (nik.length > 0) { 
            $.ajax({
                url: "/fetch-user-data",
                type: 'GET',
                data: { nik: nik }, 
                success: function(response) {
                    if (response.success) {
                        $('#nama').val(response.nama);
                        $('#kode_org').val(response.kode_org);
                        $('#nik-status').text('');
                    } else {
                        $('#nama').val('');
                        $('#kode_org').val('');
                        $('#nik-status').text('nik tidak ada');
                    }
                },
                error: function(xhr) {
                    console.log(xhr);
                }
            });
        } else {
            $('#nama').val('');
            $('#kode_org').val('');
        }
    }
</script>

@endsection