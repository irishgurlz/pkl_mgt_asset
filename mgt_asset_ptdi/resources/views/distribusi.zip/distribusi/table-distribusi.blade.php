<tbody>
    @forelse ($distribution as $key => $item)    
    <tr>
        <td>{{$key + 1}}</td>
        <td>{{$item->nomor_penyerahan}}</td>
        <td>{{$item->employee->nama}}</td>
        <td>{{$item->lokasi}}</td>
        <td>{{$item->nomor_it}}</td>
        <td>
            {{-- @dd($item->device->serialType); --}}
            {{-- <a href="/asset/create">Detail Device</a> --}}
            {{-- <a class="btn btn-info" data-bs-toggle="modal" data-bs-target="#modal-detail-device" 
                data-nomor-it="{{$item->nomor_it}}"
                data-nomor-pmn="{{$item->device->no_pmn}}"
                data-kategori="{{$item->asset->kategori->nama ?? '-'}}"
                data-processor="{{$item->asset->processorType->nama}}"
                data-tipe="{{$item->asset->subKategori->nama}}"
                data-umur="{{$item->asset->umur}}"
                data-storage-type="{{$item->asset->storageType->nama}}"
                data-storage-capacity="{{$item->asset->storage_capacity}}"
                data-memory-type="{{$item->asset->memoryType->nama}}"
                data-memory-capacity="{{$item->asset->memory_capacity}}"
                data-vga-type="{{$item->asset->vgaType->nama}}"
                data-vga-capacity="{{$item->asset->vga_capacity}}"
                data-serial_type="{{$item->asset->serial_number}}"
                data-os="{{$item->asset->operationSystem->nama}}"
                data-os-license="{{$item->asset->osLicense->nama}}"
                data-office="{{$item->asset->officeType->nama}}"
                data-office-license="{{$item->asset->officeLicense->nama}}"
                data-aplikasi="{{$item->asset->aplikasi_lainnya ?? '-'}}"
                data-keterangan="{{$item->asset->keterangan_tambahan ?? '-'}}"> 
                Detail Asset
            </a> --}}

        </td>
    
        <td class="d-flex justify-content-start">
            {{-- <div class="me-2">
                <a class="btn btn-warning" href="{{ url('/asset/'.$item->nomor_asset.'/device/'.$item->device->id.'/edit') }}">Edit</a>
            </div> --}}

            <div class="me-2">
                    {{-- <a class="btn btn-warning" href="{{ url('/distribusi/'.$item->nomor_penyerahan.'/asset/'.$item->device->id.'/editPengalihan') }}">Pengalihan</a> --}}
                </a>
            </div>

            {{-- <form action="{{ url('/distribusi/'.$item->nomor_penyerahan.'/asset/'.$item->asset->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this asset?');" style="padding: 0; margin: 0;">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger" type="submit" style="">
                    Delete
                </button> --}}
            </form>
        </td>
    </tr>
    @empty
    <tr>
        <td colspan="7" class="text-center">Tidak ada data aset</td>
    </tr>
    @endforelse
</tbody>