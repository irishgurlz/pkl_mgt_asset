<form action="/distribution-asset" id="form-add-asset" method="POST" enctype="multipart/form-data">
    @csrf
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="row">
        <div class="mb-2">
            <label for="">Nomor Penyerahan</label>
            <input type="text" class="form-control" name="nomor_penyerahan" id="nomor_penyerahan_hidden" value="{{ session('nomor_penyerahan') }}" style="background-color: #f2f2f2;" readonly>
        </div>
    </div>

    <div class="row">
        <!-- Kolom Kiri -->
        <div class="col col-6">
            <div class="row">
                <!-- Card Asset -->
                <div class="card shadow mb-3">
                    <div class="card-header py-3 text-center">
                        <h6 class="m-0 font-weight-bold text-gray">Asset</h6>
                    </div>
                    <div class="card-body">
                        <!-- Nomor Asset -->
                        <div class="form-group mb-3">
                            <label for="nomor_asset" class="form-label">Nomor Asset</label>
                            <input type="text" name="nomor_asset" id="nomor_asset" placeholder="Masukkan Nomor Asset" class="form-control" onkeyup="fetchAssetData()" required>
                            <div id="nomor_asset-status" style="color: red; font-size: 14px;"></div>
                            @error('nomor_asset')
                                <div class="alert alert-danger">{{$message}}</div>
                            @enderror
                        </div>

                        <!-- Nomor PMN -->
                        <div class="form-group mb-3">
                            <label for="no_pmn" class="form-label">Nomor PMN</label>
                            <input type="text" id="no_pmn" name="no_pmn" class="form-control" readonly>
                            @error('no_pmn')
                                <div class="alert alert-danger">{{$message}}</div>
                            @enderror
                        </div>

                        <!-- Kategori -->
                        <div class="form-group mb-3">
                            <label for="id_kategori" class="form-label">Kategori</label>
                            <input type="text" id="id_kategori" name="id_kategori" class="form-control" readonly style="background-color: #f2f2f2;">
                            @error('id_kategori')
                                <div class="alert alert-danger">{{$message}}</div>
                            @enderror
                        </div>

                        <!-- Tipe Kategori -->
                        <div class="form-group mb-3">
                            <label for="id_tipe" class="form-label">Tipe Kategori</label>
                            <input type="text" id="id_tipe" name="id_tipe" class="form-control" readonly style="background-color: #f2f2f2;">
                            @error('id_tipe')
                                <div class="alert alert-danger">{{$message}}</div>
                            @enderror
                        </div>

                        <!-- Tanggal Masuk dan Umur -->
                        <div class="form-group mb-3">
                            <label for="umur" class="form-label">Tanggal Masuk</label>
                            <input type="date" name="umur" id="umur" class="form-control" readonly style="background-color: #f2f2f2;">
                            <div class="d-flex justify-content-between">
                                <div class="align-items-center mt-3">
                                    <label for="umur" class="form-label">Umur saat ini</label>
                                </div>
                                <div style="width: 80%;">
                                    <input type="text" id="umur_tahun" placeholder="Umur dalam tahun" class="form-control mt-2" readonly style="background-color: #f2f2f2;">
                                </div>
                            </div>
                            @error('umur')
                                <div class="alert alert-danger">{{$message}}</div>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan -->
        <div class="col col-6">
            <div>
                <div class="card shadow mb-3">
                    <div class="card-header py-3 text-center">
                        <h6 class="m-0 font-weight-bold text-gray">Distribusi</h6>
                    </div>

                    <div class="card-body">
                        <label for="file" class="form-label">Dokumen</label>
                        <input type="file" name="file" class="form-control">
                        @error('file')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="card-body">
                        <div class="form-group">
                            <label for="tanggal" class="form-label">Tanggal</label>
                            <input type="date" name="tanggal" id="tanggal" placeholder="Masukkan Tanggal" class="form-control" required>
                            @error('tanggal')
                                <div class="alert alert-danger">{{$message}}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="card-body">
                        <label for="deskripsi" class="form-label">Deskripsi</label>
                        <textarea class="form-control" name="deskripsi" placeholder="Deskripsi" style="height:150px;"></textarea>
                        @error('deskripsi')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tombol Submit -->
    <div id="tambah-asset-button" class="tab-content">
        <div class="d-flex justify-content-end mb-3">
            <button type="button" class="btn btn-danger me-2" style="width: 120px;">Batal</button>
            <button type="submit" class="btn btn-primary" style="width: 120px;">Tambah</button>
        </div>
    </div>
</form>
