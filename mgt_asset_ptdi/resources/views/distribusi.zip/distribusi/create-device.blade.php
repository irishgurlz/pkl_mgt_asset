{{-- <div id="tambah-device" class="tab-content"> --}}
    <form action="/distribution-asset" id="form-add-asset" method="POST" enctype="multipart/form-data">
        @csrf
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        <div class="row">
            <div class="mb-2">
                <label>Nomor Penyerahan</label>
                <input type="text" class="form-control" name="nomor_penyerahan" id="nomor_penyerahan_hidden" value="{{ session('nomor_penyerahan') }}" style="background-color: #f2f2f2;" readonly>
            </div>
        </div>
            <div class="row">
                <div class=" col col-6">
                    <div class="'row">
                        <!-- Card Perangkat -->
                    <div class="card shadow mb-3">
                        <div class="card-header py-3 text-center">
                            <h6 class="m-0 font-weight-bold text-gray">Perangkat</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <!-- Nomor IT -->
                                <div class="form-group mb-3">
                                    <label for="nomor_it" class="form-label" >Nomor IT</label>
                                    <input type="text" name="nomor_it" id="nomor_it" placeholder="Masukkan Nomor IT" class="form-control" onkeyup="fetchDeviceData()" required>
                                    <div id="nomor_it-status" style="color: red; font-size: 14px;"></div>
                                    @error('nomor_it')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>

                                <div class="form-group mb-3">
                                    <label for="no_pmn" class="form-label">Nomor PMN</label>
                                    <input type="text" id="no_pmn" name="no_pmn" class="form-control"  style="background-color: #f2f2f2;" value="" readonly>
                                    <input type="hidden" name="no_pmn" value="">
                                    @error('no_pmn')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                
                                <!-- Kategori -->
                                <div class="form-group mb-3">
                                    <label for="id_kategori" class="form-label">Kategori</label>
                                    <input type="text" id="id_kategori" name="id_kategori" class="form-control"  style="background-color: #f2f2f2;" value="" readonly>
                                    <input type="hidden" name="id_kategori" value="">
                                    @error('id_kategori')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                

                                <!-- Tipe Kategori -->
                                <div class="form-group mb-3">
                                    <label for="id_tipe" class="form-label">Tipe Kategori</label>
                                    <input type="text" id="id_tipe" name="id_tipe"  style="background-color: #f2f2f2;" class="form-control" value="" readonly>
                                    <input type="hidden" name="id_tipe" value="">

                                    @error('id_tipe')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>

                                <div class="form-group mb-3">
                                    <label for="umur" class="form-label">Tanggal Masuk</label>
                                    <input type="date"  name="umur" id="umur" style="background-color: #f2f2f2;" placeholder="Masukkan Tanggal"  class="form-control" required readonly value="">
                                    <div class="d-flex justify-content-between">
                                        <div class="align-items-center mt-3">
                                            <label for="umur" class="form-label">Umur saat ini</label>
                                        </div>
                                        <div style="width:80%">
                                            <input type="text" id="umur_tahun" placeholder="Umur dalam tahun" class="form-control mt-2" style="background-color: #f2f2f2;" readonly>
                                        </div>
                                    </div>
                                    @error('umur')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                    const dateInput = document.getElementById('umur');
                                    const umurTahunInput = document.getElementById('umur_tahun');

                                    function calculateAge(dateOfBirth) {
                                        const today = new Date();
                                        const birthDate = new Date(dateOfBirth);
                                        let age = today.getFullYear() - birthDate.getFullYear();
                                        const monthDiff = today.getMonth() - birthDate.getMonth();

                                        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                                            age--;
                                        }
                                        return age;
                                    }

                                    dateInput.addEventListener('change', function() {
                                        const umur = calculateAge(dateInput.value);
                                        umurTahunInput.value = umur >= 0 ? `${umur} tahun` : 'Tanggal tidak valid';
                                    });

                                    if (dateInput.value) {
                                        const umur = calculateAge(dateInput.value);
                                        umurTahunInput.value = umur >= 0 ? `${umur} tahun` : 'Tanggal tidak valid';
                                    }
                                });
                                </script>
                                
                            </div>

                            <div class="row">
                                <!-- Kolom Pertama -->
                                <div class="col col-6">
                                    <!-- Processor -->
                                    <div class="form-group mb-3">
                                        <label for="processor" class="form-label">Processor</label>
                                        <input type="text" id="processor" name="processor" class="form-control"  style="background-color: #f2f2f2;" value="{{ old('processor', $distribution->asset->processorType->nama ?? '') }}" readonly>
                                        <input type="hidden" name="processor" value="">

                                        @error('processor')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                    
                                    <!-- Storage Type -->
                                    <div class="form-group mb-3">
                                        <label for="storage_type" class="form-label">Storage Type</label>
                                        <input type="text" id="storage_type" name="storage_type" class="form-control"  style="background-color: #f2f2f2;"  value="{{ old('storage_type', $distribution->asset->storageType->nama ?? '') }}" readonly>
                                        <input type="hidden" name="storage_type" value="">

                                        @error('storage_type')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                    
                                    <!-- Memory Type -->
                                    <div class="form-group mb-3">
                                        <label for="memory_type" class="form-label">Memory Type</label>
                                        <input type="text" name="memory_type" id="memory_type" class="form-control"  style="background-color: #f2f2f2;" value="{{ old('memory_type', $distribution->asset->memoryType->nama ?? '') }}" readonly>
                                        <input type="hidden" name="memory_type" value="">
                                        @error('memory_type')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>

                                    <!-- VGA Type -->
                                    <div class="form-group mb-3">
                                        <label for="vga_type" class="form-label">VGA Type</label>
                                        <input type="text" name="vga_type" id="vga_type" class="form-control"  style="background-color: #f2f2f2;" value="{{ old('vga_type', $distribution->asset->vgaType->nama ?? '') }}" readonly>
                                        <input type="hidden" name="vga_type" value="">
                                        @error('vga_type')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Kolom Kedua -->
                                <div class="col col-6">
                                    <div class="form-group mb-3">
                                        <label for="serial_number" class="form-label">Serial Number</label>
                                        <input type="text" name="serial_number" id="serial_number" placeholder="Masukkan Serial Number" class="form-control"  style="background-color: #f2f2f2;" value="" required readonly>
                                        <input type="hidden" name="serial_number" value="">
                                    
                                        @error('serial_number')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                                    
                    
                                    <!-- Storage Capacity -->
                                    <div class="form-group mb-3">
                                        <label for="storage_capacity" class="form-label">Storage Capacity</label>
                                        <input type="text" name="storage_capacity" id="storage_capacity" placeholder="Storage Capacity GB" class="form-control" style="background-color: #f2f2f2;" value="" required readonly>
                                        @error('storage_capacity')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                    
                                    <!-- Memory Capacity -->
                                    <div class="form-group mb-3">
                                        <label for="memory_capacity" class="form-label">Memory Capacity</label>
                                        <input type="text" name="memory_capacity" id="memory_capacity" placeholder="Memory Capacity GB" class="form-control"  style="background-color: #f2f2f2;" value="" required readonly>
                                        @error('memory_capacity')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                    
                                    <!-- VGA Capacity -->
                                    <div class="form-group mb-3">
                                        <label for="vga_capacity" class="form-label">VGA Capacity</label>
                                        <input type="text" name="vga_capacity" id="vga_capacity" placeholder="VGA Capacity GB" class="form-control"  style="background-color: #f2f2f2;" value="" required readonly>
                                        @error('vga_capacity')
                                            <div class="alert alert-danger">{{$message}}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label for="keterangan_tambahan" class="form-label">Keterangan Tambahan</label>
                                <textarea class="col-lg-12" name="keterangan_tambahan" id="keterangan_tambahan" style="background-color: #f2f2f2; height:150px;" placeholder="Keterangan Tambahan" readonly></textarea>
                                @error('keterangan_tambahan')
                                    <div class="alert alert-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    </div>
                    
                </div>

                <div class=" col col-6">
                    <div>
        
                    <!-- Card Aplikasi -->
                    <div class="card shadow mb-3">
                        <div class="card-header py-3 text-center">
                            <h6 class="m-0 font-weight-bold text-gray">Aplikasi</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <!-- Kolom Pertama -->
                                <div class="row">
                                    <div class="col col-6">
                                        <!-- Memory Type -->
                                        <div class="form-group mb-3">
                                            <label for="operation_system" class="form-label">Operation System</label>
                                            <input type="text" name="operation_system" id="operation_system"  style="background-color: #f2f2f2;" class="form-control" 
                                                value="" readonly>
                                            <input type="hidden" name="operation_system" 
                                                value="">
                                            
                                            @error('operation_system')
                                                <div class="alert alert-danger">{{$message}}</div>
                                            @enderror
                                        </div>
                                        
                                        <!-- Office Type -->
                                        <div class="form-group mb-3">
                                            <label for="office" class="form-label">Office Type</label>
                                            <input type="text" name="office" id="office"  style="background-color: #f2f2f2;" class="form-control" value="" readonly>
                                            <input type="hidden" name="office" 
                                                value="">
                                            
                                            @error('office')
                                                <div class="alert alert-danger">{{$message}}</div>
                                            @enderror
                                        </div>
                                        
                                    </div>
                                    
                                    <!-- Kolom Kedua -->
                                    <div class="col col-6">
                                        <div class="form-group mb-3">
                                            <label for="os_license" class="form-label">Operation System License</label>
                                            <input type="text" name="os_license" id="os_license" class="form-control"  style="background-color: #f2f2f2;"  value="" readonly>
                                            <input type="hidden" name="os_license" 
                                                value="">
                                            
                                            @error('os_license')
                                                <div class="alert alert-danger">{{$message}}</div>
                                            @enderror
                                        </div>
                                        
                                        <!-- Office License -->
                                        <div class="form-group mb-3">
                                            <label for="office_license" class="form-label">Office License</label>
                                            <input type="text" name="office_license" id="office_license" class="form-control"  style="background-color: #f2f2f2;"  value="" readonly>
                                            <input type="hidden" name="office_license" 
                                                value="">
                                            
                                            @error('office_license')
                                                <div class="alert alert-danger">{{$message}}</div>
                                            @enderror
                                        </div>
                                        
                                    </div>
                                </div>  
                                
                                <!-- Aplikasi Lainnya -->
                                <div class="form-group mb-3">
                                    <label for="aplikasi_lainnya" class="form-label">Aplikasi Lainnya</label>
                                    <input type="text" name="aplikasi_lainnya" id="aplikasi_lainnya" placeholder="Aplikasi Lainnya" class="form-control"  style="background-color: #f2f2f2;" value="" required>
                                    @error('aplikasi_lainnya')
                                        <div class="alert alert-danger">{{$message}}</div>
                                    @enderror
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="card shadow mb-3">
                        <div class="card-header py-3 text-center">
                            <h6 class="m-0 font-weight-bold text-gray">Distribusi</h6>
                        </div>
                        <div class="card-body">
                            <label for="file" class="form-label">Dokumen</label>
                            <input type="file" name="file" class="form-control" value="" >
                            @error('file')
                                <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                        </div>


                        <div class="card-body">
                            <div class="form-group ">
                                <label for="tanggal" class="form-label" value="">Tanggal</label>
                                <input type="date" name="tanggal" id="tanggal" placeholder="Masukkan Tanggal" class="form-control" value="" required>
                                @error('tanggal')
                                    <div class="alert alert-danger">{{$message}}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="card-body">
                            <label for="lokasi" class="form-label">Deskripsi</label>
                            <textarea class="col-lg-12" name="deskripsi" placeholder="Deskripsi" style="height:150px;"></textarea>
                            @error('deskripsi')
                                <div class="alert alert-danger">{{$message}}</div>
                            @enderror
                        </div>
                    </div>
            
                </div>
                </div>
            </div>
            <div class="tambah-device-button">
                <div class="d-flex justify-content-end mt-4">
                    <button type="button" class="btn btn-danger me-2" style="width: 120px;">Batal</button>
                    <button type="submit" class="btn btn-primary" style="width: 120px;">Tambah</button>
                </div>
            </div>
        </form>
    </div>