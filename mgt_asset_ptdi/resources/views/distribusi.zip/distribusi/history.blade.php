@extends('employee.master')

@section('content')

    <!-- TITLE -->
   <div class="container" data-aos="fade-up">
        <div class ="section-title" data-aos="fade-up" >
            <h2>History Distribusi Asset</h2>
        </div>

        <div class="container-fluid">
            <div class="card shadow mb-4">
                <div class="card-header py-3">

                </div>
                
                <!-- TABEL -->
                <div class="card-body">
                    <div class="table-responsive">
                        @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif
                        <table class="table table-bordered table-hover" id="tabel_kategori" width="100%" cellspacing="0" style="table-layout: auto;">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nomor Penyerahan</th>
                                    <th>Pemilik Aset Saat Ini</th>
                                    <th>Lokasi</th>
                                    <th>Nomor IT</th>
                                    <th>Detail</th>
                                </tr>
                            </thead>

                            <tbody>
                                @forelse ($history as $key => $item)    
                                <tr>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nomor_penyerahan }}</td>
                                    <td>{{$item->distribution->employee->nama}}</td>
                                    <td>{{$item->distribution->lokasi}}</td>
                                    <td>{{$item->distribution->nomor_it}}</td>
                                    <td>
                                        {{-- <a href="/asset/create">Detail Device</a> --}}
                                        <a class="btn btn-info"  href="/history/{{$item->id}}/distribusi/{{$item->distribution->id}}">
                                            Detail History
                                        </a>
    
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center">Tidak ada data history</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                        {{-- @include('paginate', ['paginator' => $history]) --}}

                    </div>
                </div>
        </div>
        
   </div>
@endsection