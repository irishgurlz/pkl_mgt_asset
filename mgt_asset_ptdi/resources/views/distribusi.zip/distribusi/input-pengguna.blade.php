<form action="/distribusi" id="form-add-asset" method="POST" onsubmit="handleFormSubmit(event)">
    @csrf
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <div class="row">
        <div class="form-group mb-3">
            <label for="nomor_penyerahan" class="form-label">Nomor Penyerahan</label>
            <input type="text" name="nomor_penyerahan" id="nomor_penyerahan" placeholder="Masukkan Nomor Penyerahan" class="form-control" required onkeyup="updateNomorPenyerahan()">
            @error('nomor_penyerahan')
                <div class="alert alert-danger">{{$message}}</div>
            @enderror
        </div>
    </div>
    <div class="row">
        <div class="row">
            <div class="card shadow mb-3">
                <div class="card-header py-3 text-center">
                    <h6 class="m-0 font-weight-bold text-gray">Pengguna</h6>
                </div>
                <div class="card-body">
                    <!-- NIK -->
                    <div class="form-group mb-3">
                        <label for="nik" class="form-label">NIK</label>
                        <input type="text" name="nik" id="nik" placeholder="Masukkan NIK" class="form-control" onkeyup="fetchUserData()" required>
                        <div id="nik-status" style="color: red; font-size: 14px;"></div>
                        @error('nik')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror
                    </div>

                    <!-- Nama Pemilik Asset -->
                    <div class="form-group mb-3">
                        <label for="nama" class="form-label">Nama</label>
                        <input type="text" name="nama" id="nama" placeholder="Nama" class="form-control" style="background-color: #f2f2f2;" required readonly>
                        @error('nama')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror
                    </div>

                    <!-- Organisasi -->
                    <div class="form-group mb-3">
                        <label for="kode_org" class="form-label">Organisasi</label>
                        <input type="text" name="kode_org" id="kode_org" placeholder="Organisasi" class="form-control" style="background-color: #f2f2f2;" required readonly>
                        @error('kode_org')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror
                    </div>

                    <!-- Lokasi -->
                    <div class="form-group mb-3">
                        <label for="lokasi" class="form-label">Lokasi</label>
                        <input type="text" name="lokasi" id="lokasi" placeholder="Masukkan Lokasi" class="form-control" required>
                        @error('lokasi')
                            <div class="alert alert-danger">{{$message}}</div>
                        @enderror
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Tombol Submit -->
    <div class="input-pengguna-button">
        <div class="d-flex justify-content-end mt-4">
            <button type="button" class="btn btn-danger me-2" style="width: 120px;">Batal</button>
            <button type="submit" class="btn btn-primary" style="width: 120px;">Tambah</button>
        </div>
    </div>
</form>
<!-- Input Hidden -->
<input type="hidden" name="nomor_penyerahan_hidden" id="nomor_penyerahan_hidden_form2" value="">
<script>
    // Ketika nomor_penyerahan diisi di form pertama, update form kedua
    document.getElementById('nomor_penyerahan').addEventListener('input', function () {
        const nomorPenyerahan = this.value;
        document.getElementById('nomor_penyerahan_hidden_form2').value = nomorPenyerahan;
    });
</script>
